$=document.querySelector.bind(document);
$=document.querySelectorAll.bind(document);
let editButton=$('.edit__profile');
editButton.onclick=()=>{
    
}